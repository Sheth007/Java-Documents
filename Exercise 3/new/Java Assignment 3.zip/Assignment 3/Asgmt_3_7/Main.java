import MathPack.MathDemo;

public class Main {
    public static void main(String[] args) {
        int a = 10;
        int b = 50;
        int ad = MathDemo.add(a, b);
        int su = MathDemo.sub(a, b);
        System.out.println("Addition is:" + ad);
        System.out.println("Substraction is:" + su);
    }
}
