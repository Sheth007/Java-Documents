class Main {
    public static void main(String[] args) {
        String str = "Java Programming";
        int len = str.length();
        System.out.println("Length of String is:" + len);
        String substr = str.substring(0, 4);
        System.out.println("Sub String is:" + substr);
    }
}