public class A 
{ 
    public static void main(String[] args) {
		String str = "Atmiya University";
		System.out.println("3rd character in the string 'Atmiya University' is: " + str.charAt(2));
	}
}
