import java.awt.*;
import java.applet.Applet;

/*
    <applet code="face" width=400 height=400> </applet>
*/

public class face extends Applet
{
    public void paint(Graphics g)
    {
        g.drawOval(80, 70, 150, 150);
        g.setColor(Color.BLACK);
        g.fillOval(120, 120, 15, 15);
        g.fillOval(170, 120, 15, 15);
        g.drawLine(140,170,150,130);
        g.drawLine(140,170,160,170);
        g.drawArc(130, 180, 50, 20, 180, 180);
    }
}